use codoacodo;
create table alumnos (id int(11) primary key auto_increment, nombre varchar(40), apellido varchar(40), edad tinyint(2), fecha timestamp 
, provincia varchar(30))
INSERT INTO alumnos(id, nombre, apellido, edad, fecha, provincia) VALUES ('3','Julio Jose','Romero','20','2003/01/20','Tucumán');
